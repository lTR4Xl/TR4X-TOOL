from pystyle import *
import requests
from mcquery import mcquery
import random
import string
import pystyle
import base64
import os
from cryptography.fernet import Fernet
import sys, re, time, random, os.path, string, subprocess, threading, ctypes, shutil
from colorama import Fore
from time import sleep
import csv
import hashlib


w = Fore.LIGHTRED_EX
b = Fore.BLACK
g = Fore.LIGHTGREEN_EX
y = Fore.LIGHTYELLOW_EX
m = Fore.RED
c = Fore.LIGHTCYAN_EX
lr = Fore.LIGHTRED_EX
lb = Fore.WHITE

os.system("title GMS")

sayuri = '''

  ▄████  ███▄ ▄███▓  ██████ 
 ██▒ ▀█▒▓██▒▀█▀ ██▒▒██    ▒ 
▒██░▄▄▄░▓██    ▓██░░ ▓██▄   
░▓█  ██▓▒██    ▒██   ▒   ██▒
░▒▓███▀▒▒██▒   ░██▒▒██████▒▒
 ░▒   ▒ ░ ▒░   ░  ░▒ ▒▓▒ ▒ ░
  ░   ░ ░  ░      ░░ ░▒  ░ ░
░ ░   ░ ░      ░   ░  ░  ░  
      ░        ░         ░  


'''
System.Size(120, 30)
System.Clear()
Anime.Fade(Center.Center(sayuri), Colors.black_to_white, Colorate.Vertical, interval=0.1, enter=True)




import modules.title as title

title.start()



def getheaders(token=None):
    headers = random.choice(heads)
    if token:
        headers.update({"Authorization": token})
    return headers

def getTempDir():
    system = os.name
    if system == 'nt':
        return os.getenv('temp')
    elif system == 'posix':
        return '/tmp/'

def proxy_scrape(): 
    proxieslog = []
    startTime = time.time()
    temp = getTempDir()+"\\atio_proxies"

    def fetchProxies(url, custom_regex):
        global proxylist
        try:
            proxylist = requests.get(url, timeout=5).text
        except Exception:
            pass
        finally:
            proxylist = proxylist.replace('null', '')
        custom_regex = custom_regex.replace('%ip%', '([0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3})')
        custom_regex = custom_regex.replace('%port%', '([0-9]{1,5})')
        for proxy in re.findall(re.compile(custom_regex), proxylist):
            proxieslog.append(f"{proxy[0]}:{proxy[1]}")

    proxysources = [
        ["http://spys.me/proxy.txt","%ip%:%port% "],
        ["http://www.httptunnel.ge/ProxyListForFree.aspx"," target=\"_new\">%ip%:%port%</a>"],
        ["https://raw.githubusercontent.com/sunny9577/proxy-scraper/master/proxies.json", "\"ip\":\"%ip%\",\"port\":\"%port%\","],
        ["https://raw.githubusercontent.com/fate0/proxylist/master/proxy.list", '"host": "%ip%".*?"country": "(.*?){2}",.*?"port": %port%'],
        ["https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list.txt", '%ip%:%port% (.*?){2}-.-S \\+'],
        ["https://raw.githubusercontent.com/opsxcq/proxy-list/master/list.txt", '%ip%", "type": "http", "port": %port%'],
        ["https://www.us-proxy.org/", "<tr><td>%ip%<\\/td><td>%port%<\\/td><td>(.*?){2}<\\/td><td class='hm'>.*?<\\/td><td>.*?<\\/td><td class='hm'>.*?<\\/td><td class='hx'>(.*?)<\\/td><td class='hm'>.*?<\\/td><\\/tr>"],
        ["https://free-proxy-list.net/", "<tr><td>%ip%<\\/td><td>%port%<\\/td><td>(.*?){2}<\\/td><td class='hm'>.*?<\\/td><td>.*?<\\/td><td class='hm'>.*?<\\/td><td class='hx'>(.*?)<\\/td><td class='hm'>.*?<\\/td><\\/tr>"],
        ["https://www.sslproxies.org/", "<tr><td>%ip%<\\/td><td>%port%<\\/td><td>(.*?){2}<\\/td><td class='hm'>.*?<\\/td><td>.*?<\\/td><td class='hm'>.*?<\\/td><td class='hx'>(.*?)<\\/td><td class='hm'>.*?<\\/td><\\/tr>"],
        ["https://api.proxyscrape.com/?request=getproxies&proxytype=http&timeout=6000&country=all&ssl=yes&anonymity=all", "%ip%:%port%"],
        ["https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/http.txt", "%ip%:%port%"],
        ["https://raw.githubusercontent.com/shiftytr/proxy-list/master/proxy.txt", "%ip%:%port%"],
        ["https://proxylist.icu/proxy/", "<td>%ip%:%port%</td><td>http<"],
        ["https://proxylist.icu/proxy/1", "<td>%ip%:%port%</td><td>http<"],
        ["https://proxylist.icu/proxy/2", "<td>%ip%:%port%</td><td>http<"],
        ["https://proxylist.icu/proxy/3", "<td>%ip%:%port%</td><td>http<"],
        ["https://proxylist.icu/proxy/4", "<td>%ip%:%port%</td><td>http<"],
        ["https://proxylist.icu/proxy/5", "<td>%ip%:%port%</td><td>http<"],
        ["https://www.hide-my-ip.com/proxylist.shtml", '"i":"%ip%","p":"%port%",'],
        ["https://raw.githubusercontent.com/scidam/proxy-list/master/proxy.json", '"ip": "%ip%",\n.*?"port": "%port%",']
    ]
    threads = [] 
    for url in proxysources:
        t = threading.Thread(target=fetchProxies, args=(url[0], url[1]))
        threads.append(t)
        t.start()
    for t in threads:
        t.join()

    proxies = list(set(proxieslog))
    with open(temp, "w") as f:
        for proxy in proxies:
            for i in range(random.randint(7, 10)):
                f.write(f"{proxy}\n")
    execution_time = (time.time() - startTime)
    

def proxy():
    temp = getTempDir()+"\\atio_proxies"
    if os.stat(temp).st_size == 0:
        proxy_scrape()
    proxies = open(temp).read().split('\n')
    proxy = proxies[0]

    with open(temp, 'r+') as fp:
        lines = fp.readlines()
        fp.seek(0)
        fp.truncate()
        fp.writelines(lines[1:])
    return ({'http://': f'http://{proxy}', 'https://': f'https://{proxy}'})

heads = [
    {
        "Content-Type": "application/json",
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:76.0) Gecko/20100101 Firefox/76.0'
    },

    {
        "Content-Type": "application/json",
        "User-Agent": "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:72.0) Gecko/20100101 Firefox/72.0"
    },

    {
        "Content-Type": "application/json",
        "User-Agent": "Mozilla/5.0 (X11; Debian; Linux x86_64; rv:72.0) Gecko/20100101 Firefox/72.0"
    },

    {
        "Content-Type": "application/json",
        'User-Agent': 'Mozilla/5.0 (Windows NT 3.1; rv:76.0) Gecko/20100101 Firefox/69.0'
    },

    {
        "Content-Type": "application/json",
        "User-Agent": "Mozilla/5.0 (X11; Debian; Linux x86_64; rv:72.0) Gecko/20100101 Firefox/76.0"
    },

    {
       "Content-Type": "application/json",
       "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11"
    }
]

def clear():
    system = os.name
    if system == 'nt':
        os.system('cls')
    elif system == 'posix':
        os.system('clear')
    else:
        print('\n'*120)
    return

import os
import time

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def animate():
    LocheMan = ['.','..','...', 'G' ,'GM' ,'GMS' ,'GMS x' ,'GMS x T','GMS x TR' ,'GMS x TR4' ,'GMS x TR4X' ,'GMS x TR4' ,'GMS x TR' ,'GMS x T' ,'GMS x ' \
                ,'GMS' ,'GM' ,'G','GM','GMS' ,'GMS x' ,'GMS x T','GMS x TR' ,'GMS x TR4' ,'GMS x TR4X']
    
    sayuri = ''' 
                            ______________  __________          ____________________ _____  __
                            __  ____/__   |/  /_  ___/ ____  __ ___  __/__  __ \_  // /_  |/ /
                            _  / __ __  /|_/ /_____ \  __  |/_/ __  /  __  /_/ /  // /__    / 
                            / /_/ / _  /  / / ____/ /  __>  <   _  /   _  _, _//__  __/    |  
                            \____/  /_/  /_/  /____/   /_/|_|   /_/    /_/ |_|   /_/  /_/|_|   
                 
                                  [1] Searcher DB FM              [8]  Searcher DB PLAY
                                  [2] Searcher DB MAIL            [9]  Searcher DB EPIC
                                  [3] Searcher DB MASTERCARD      [10] Searcher DB BDV
                                  [4] Searcher DB PAYPAL          [11] Searcher DB DISCORD         
                                  [5] Searcher DB ROBLOX          [12] Searcher DB MINECRAFT
                                  [6] Searcher DB SNAPCHAT        [13] LOOKUP
                                  [7] Searcher DB VALORANT        [14] EXIT\n\n\n  '''                                                         
    for frame in LocheMan:
        clear()
        print(sayuri + frame)
        time.sleep(0.1)
                                                     
    

def static():
    LocheMan = ['.','..','...', 'G' ,'GM' ,'GMS' ,'GMS x' ,'GMS x T','GMS x TR' ,'GMS x TR4' ,'GMS x TR4X' ,'GMS x TR4' ,'GMS x TR' ,'GMS x T' ,'GMS x ' \
                ,'GMS' ,'GM' ,'G','GM','GMS' ,'GMS x' ,'GMS x T','GMS x TR' ,'GMS x TR4' ,'GMS x TR4X']
    statique = ''' 
                            ______________  __________          ____________________ _____  __
                            __  ____/__   |/  /_  ___/ ____  __ ___  __/__  __ \_  // /_  |/ /
                            _  / __ __  /|_/ /_____ \  __  |/_/ __  /  __  /_/ /  // /__    / 
                            / /_/ / _  /  / / ____/ /  __>  <   _  /   _  _, _//__  __/    |  
                            \____/  /_/  /_/  /____/   /_/|_|   /_/    /_/ |_|   /_/  /_/|_|
\n    '''
    for frame in LocheMan:
        clear()
        print(statique + frame)
        time.sleep(0.1)

def main():
    clear()
    static()
    time.sleep(2)  # Attendez 2 secondes avant d'afficher l'animation
    clear()
    print(animate())

main()







def query(ip, port):
 with mcquery(ip, port=port, timeout=10) as data:
  print(f'''{Colors.purple}
      Statut:{Colors.white} Online (🟢)\n    
      IP:{Colors.white} {data.host_ip}\n    
      Port:{Colors.white} {data.host_port}\n         
      Nombre de joueur en ligne:{Colors.white} {data.num_players} / {data.max_players}\n          
      Version du serveur:{Colors.white} {data.version} \n
      Plugins:{Colors.white} {data.plugins}\n  
      MOTD:{Colors.white} {data.motd}
''') 
  
def IpOption(ip):
    api = f"http://ip-api.com/json/{ip}"
    data = requests.get(api).json()
    print("")
    print("")
    print(f"{Colors.purple}Victim:", data['query'])
    print("")
    print(f"{Colors.purple}Fournisseur Internet:{Colors.white}", data['isp'])
    print("")
    print(f"{Colors.purple}Organisation:{Colors.white}", data['org'])
    print("")
    print(f"{Colors.purple}Ville:{Colors.white}", data['city'])
    print("")
    print(f"{Colors.purple}Region:{Colors.white}", data['region'])
    print("")
    print(f"{Colors.purple}Longitude:{Colors.white}", data['lon'])
    print("")
    print(f"{Colors.purple}Latitude:{Colors.white}", data['lat'])
    print("")
    print(f"{Colors.purple}Time zone:{Colors.white}", data['timezone'])
    print("")
    print(f"{Colors.purple}Code Postale:{Colors.white}", data['zip'])


while True:  
 option = input(f"{Colors.gray}[+] Options:{w} ")
 if option == "10000000000000000000":
   ip = input(f"{Colors.cyan}[+] Ip:{Colors.white} ")
   port = input (f"{Colors.cyan}[+] Port:{Colors.white} ")
   port = int(port)
   try:
    query(ip, port)
    input(f"{Colors.red}Press {Colors.purple}ENTER {Colors.red}to exit!{Colors.pink}")
    clear()
    main()
   except:
    print(f"Error :{Colors.white} (ip) / (port)") 



 if option == "154464446":
   ip = input(f"{Colors.cyan}[+] Ip:{Colors.white} ")
   try:
    IpOption(ip)
    input(f"{Colors.red}Press {Colors.blue}ENTER {Colors.red}to exit!{Colors.pink}")
    clear()
    main()
    with open("Logs/IpLogs.txt", "a+") as file:
      file.write(ip + "\n")
      file.close()
   except:
    print(f"Error :{Colors.white} IP INVALID") 
    

 if option == "1":
    clear()
    clear()
    print(f'''

                           {pystyle.Colors.white}
                           ▄████  ███▄ ▄███▓  ██████            █████▒██▓ ██▒   █▓▓█████  ███▄ ▄███▓     
                           ██▒ ▀█▒▓██▒▀█▀ ██▒▒██    ▒          ▓██   ▒▓██▒▓██░   █▒▓█   ▀ ▓██▒▀█▀ ██▒     
                          ▒██░▄▄▄░▓██    ▓██░░ ▓██▄            ▒████ ░▒██▒ ▓██  █▒░▒███   ▓██    ▓██░     
                          ░▓█  ██▓▒██    ▒██   ▒   ██▒         ░▓█▒  ░░██░  ▒██ █░░▒▓█  ▄ ▒██    ▒██      
                          ░▒▓███▀▒▒██▒   ░██▒▒██████▒▒         ░▒█░   ░██░   ▒▀█░  ░▒████▒▒██▒   ░██▒     
                           ░▒   ▒ ░ ▒░   ░  ░▒ ▒▓▒ ▒ ░          ▒ ░   ░▓     ░ ▐░  ░░ ▒░ ░░ ▒░   ░  ░     
                            ░   ░ ░  ░      ░░ ░▒  ░ ░          ░      ▒ ░   ░ ░░   ░ ░  ░░  ░      ░     
                          ░ ░   ░ ░      ░   ░  ░  ░            ░ ░    ▒ ░     ░░     ░   ░      ░        
                                ░        ░         ░                   ░        ░     ░  ░       ░                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                   
                                                                                   ''')


    def main(dossier, pseudo):
        resultat = []
    
        
        for dossier_actuel, sous_dossiers, fichiers in os.walk(dossier):
            for nom_fichier in fichiers:
                chemin_fichier = os.path.join(dossier_actuel, nom_fichier)
    
                with open(chemin_fichier, 'r', encoding='ISO-8859-1') as fichier:
                    lignes = fichier.readlines()
                    for index, ligne in enumerate(lignes):
                        if pseudo in ligne:
                            resultat.append((chemin_fichier, index+1, ligne.strip()))
                            
        return resultat
    
    
    pseudo_cherche = input(f'  {pystyle.Colors.white}Recherche : {pystyle.Colors.purple}')
    dossier_DB = "DB FIVEM"
    resultat_recherche = main(dossier_DB, pseudo_cherche)
    
    
    if resultat_recherche:
        for chemin, numero_ligne, contenu_ligne in resultat_recherche:
            print(f"Votre recherche a été trouvé dans le fichier : {chemin}")
            print(f"Ligne {numero_ligne}: {contenu_ligne}\n")
            print("\n\n--------\n\n")
    else:
        print("Votre recherche n'a pas été trouvé dans les fichiers du dossier.")

    input(f"{Colors.red}Press {Colors.blue}ENTER {Colors.red}to exit!{Colors.pink}")
    clear()
    print(f'''{Colors.blue}
                          
                  ______   __       __   ______                     ________  _______   __    __  __    __  
                 /      \ /  \     /  | /      \                   /        |/       \ /  |  /  |/  |  /  |
                /$$$$$$  |$$  \   /$$ |/$$$$$$  |       __    __   $$$$$$$$/ $$$$$$$  |$$ |  $$ |$$ |  $$ |
                $$ | _$$/ $$$  \ /$$$ |$$ \__$$/       /  \  /  |     $$ |   $$ |__$$ |$$ |__$$ |$$  \/$$/
                $$ |/    |$$$$  /$$$$ |$$      \       $$  \/$$/      $$ |   $$    $$< $$    $$ | $$  $$<
                $$ |$$$$ |$$ $$ $$/$$ | $$$$$$  |       $$  $$<       $$ |   $$$$$$$  |$$$$$$$$ |  $$$$  \ 
                $$ \__$$ |$$ |$$$/ $$ |/  \__$$ |       /$$$$  \      $$ |   $$ |  $$ |      $$ | $$ /$$  |
                $$    $$/ $$ | $/  $$ |$$    $$/       /$$/ $$  |     $$ |   $$ |  $$ |      $$ |$$ |  $$ | 
                 $$$$$$/  $$/      $$/  $$$$$$/        $$/   $$/      $$/    $$/   $$/       $$/ $$/   $$/   
                 
                                  [1] Searcher DB FM              [8]  Searcher DB PLAY
                                  [2] Searcher DB MAIL            [9]  Searcher DB EPIC
                                  [3] Searcher DB MASTERCARD      [10] Searcher DB BDV
                                  [4] Searcher DB PAYPAL          [11] Searcher DB DISCORD         
                                  [5] Searcher DB ROBLOX          [12] Searcher DB MINECRAFT
                                  [6] Searcher DB SNAPCHAT        [13] LOOKUP
                                  [7] Searcher DB VALORANT        [14] EXIT\n\n
        

''')
 if option == "2":
    clear()
    clear()
    print(f'''

                           {pystyle.Colors.white}███████╗███████╗ █████╗ ██████╗  ██████╗██╗  ██╗███████╗██████╗ 
                           ██╔════╝██╔════╝██╔══██╗██╔══██╗██╔════╝██║  ██║██╔════╝██╔══██╗
                           ███████╗█████╗  ███████║██████╔╝██║     ███████║█████╗  ██████╔╝
                           ╚════██║██╔══╝  ██╔══██║██╔══██╗██║     ██╔══██║██╔══╝  ██╔══██╗
                           ███████║███████╗██║  ██║██║  ██║╚██████╗██║  ██║███████╗██║  ██║
                           ╚══════╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                   
                                                                                   ''')


    def main(dossier, pseudo):
        resultat = []
    
        
        for dossier_actuel, sous_dossiers, fichiers in os.walk(dossier):
            for nom_fichier in fichiers:
                chemin_fichier = os.path.join(dossier_actuel, nom_fichier)
    
                with open(chemin_fichier, 'r', encoding='ISO-8859-1') as fichier:
                    lignes = fichier.readlines()
                    for index, ligne in enumerate(lignes):
                        if pseudo in ligne:
                            resultat.append((chemin_fichier, index+1, ligne.strip()))
                            
        return resultat
    
    
    pseudo_cherche = input(f'  {pystyle.Colors.white}Recherche : {pystyle.Colors.red}')
    dossier_DB = "DB MAIL"
    resultat_recherche = main(dossier_DB, pseudo_cherche)
    
    
    if resultat_recherche:
        for chemin, numero_ligne, contenu_ligne in resultat_recherche:
            print(f"Le pseudo a été trouvé dans le fichier : {chemin}")
            print(f"Ligne {numero_ligne}: {contenu_ligne}")
            print("\n--------\n")
    else:
        print("Le pseudo n'a pas été trouvé dans les fichiers du dossier.")
        input(f"{Colors.red}Entrer {Colors.white}pour {Colors.red}quitter{Colors.pink}")
    clear()
    print(f'''{Colors.blue}
                          
                                              GMS {Colors.white}X {Colors.orange}TR4X
        

        {m}[{w}1{Fore.RESET}{m}]{Fore.RESET} Searcher DB FM               {m}[{w }8{Fore.RESET}{m}]{Fore.RESET}  Searcher DB PLAY
        {m}[{w}2{Fore.RESET}{m}]{Fore.RESET} Searcher DB MAIL             {m}[{w }9{Fore.RESET}{m}]{Fore.RESET}  Searcher DB EPIC
        {m}[{w}3{Fore.RESET}{m}]{Fore.RESET} Searcher DB MASTERCARD       {m}[{w}10{Fore.RESET}{m}]{Fore.RESET} Searcher DB BDV
        {m}[{w}4{Fore.RESET}{m}]{Fore.RESET} Searcher DB PAYPAL           {m}[{w}11{Fore.RESET}{m}]{Fore.RESET} Searcher DB DISCORD         
        {m}[{w}5{Fore.RESET}{m}]{Fore.RESET} Searcher DB ROBLOX           {m}[{w}12{Fore.RESET}{m}]{Fore.RESET} Searcher DB MINECRAFT
        {m}[{w}6{Fore.RESET}{m}]{Fore.RESET} Searcher DB SNAPCHAT         {m}[{w}13{Fore.RESET}{m}]{Fore.RESET} IP Lookup
        {m}[{w}7{Fore.RESET}{m}]{Fore.RESET} Searcher DB VALORANT        {b}|{Fore.RESET}{m}[{w}14{Fore.RESET}{m}]{Fore.RESET}{lr} EXIT{Fore.RESET}
      

''')
 if option == "3":
    clear()
    clear()
    print(f'''

                           {pystyle.Colors.white}███████╗███████╗ █████╗ ██████╗  ██████╗██╗  ██╗███████╗██████╗ 
                           ██╔════╝██╔════╝██╔══██╗██╔══██╗██╔════╝██║  ██║██╔════╝██╔══██╗
                           ███████╗█████╗  ███████║██████╔╝██║     ███████║█████╗  ██████╔╝
                           ╚════██║██╔══╝  ██╔══██║██╔══██╗██║     ██╔══██║██╔══╝  ██╔══██╗
                           ███████║███████╗██║  ██║██║  ██║╚██████╗██║  ██║███████╗██║  ██║
                           ╚══════╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                   
                                                                                   ''')


    def main(dossier, pseudo):
        resultat = []
    
        
        for dossier_actuel, sous_dossiers, fichiers in os.walk(dossier):
            for nom_fichier in fichiers:
                chemin_fichier = os.path.join(dossier_actuel, nom_fichier)
    
                with open(chemin_fichier, 'r', encoding='ISO-8859-1') as fichier:
                    lignes = fichier.readlines()
                    for index, ligne in enumerate(lignes):
                        if pseudo in ligne:
                            resultat.append((chemin_fichier, index+1, ligne.strip()))
                            
        return resultat
    
    
    pseudo_cherche = input(f'  {pystyle.Colors.white}Recherche : {pystyle.Colors.red}')
    dossier_DB = "DB MASTERCARD"
    resultat_recherche = main(dossier_DB, pseudo_cherche)
    
    
    if resultat_recherche:
        for chemin, numero_ligne, contenu_ligne in resultat_recherche:
            print(f"Le pseudo a été trouvé dans le fichier : {chemin}")
            print(f"Ligne {numero_ligne}: {contenu_ligne}")
            print("\n--------\n")
    else:
        print("Le pseudo n'a pas été trouvé dans les fichiers du dossier.")
        input(f"{Colors.red}Entrer {Colors.white}pour {Colors.red}quitter{Colors.pink}")
    clear()
    print(f'''{Colors.blue}
                          
                                              GMS {Colors.white}X {Colors.orange}TR4X
        

        {m}[{w}1{Fore.RESET}{m}]{Fore.RESET} Searcher DB FM               {m}[{w }8{Fore.RESET}{m}]{Fore.RESET}  Searcher DB PLAY
        {m}[{w}2{Fore.RESET}{m}]{Fore.RESET} Searcher DB MAIL             {m}[{w }9{Fore.RESET}{m}]{Fore.RESET}  Searcher DB EPIC
        {m}[{w}3{Fore.RESET}{m}]{Fore.RESET} Searcher DB MASTERCARD       {m}[{w}10{Fore.RESET}{m}]{Fore.RESET} Searcher DB BDV
        {m}[{w}4{Fore.RESET}{m}]{Fore.RESET} Searcher DB PAYPAL           {m}[{w}11{Fore.RESET}{m}]{Fore.RESET} Searcher DB DISCORD         
        {m}[{w}5{Fore.RESET}{m}]{Fore.RESET} Searcher DB ROBLOX           {m}[{w}12{Fore.RESET}{m}]{Fore.RESET} Searcher DB MINECRAFT
        {m}[{w}6{Fore.RESET}{m}]{Fore.RESET} Searcher DB SNAPCHAT         {m}[{w}13{Fore.RESET}{m}]{Fore.RESET} IP Lookup
        {m}[{w}7{Fore.RESET}{m}]{Fore.RESET} Searcher DB VALORANT        {b}|{Fore.RESET}{m}[{w}14{Fore.RESET}{m}]{Fore.RESET}{lr} EXIT{Fore.RESET}
      
''')

 if option == "4":
    clear()
    clear()
    print(f'''

                           {pystyle.Colors.white}███████╗███████╗ █████╗ ██████╗  ██████╗██╗  ██╗███████╗██████╗ 
                           ██╔════╝██╔════╝██╔══██╗██╔══██╗██╔════╝██║  ██║██╔════╝██╔══██╗
                           ███████╗█████╗  ███████║██████╔╝██║     ███████║█████╗  ██████╔╝
                           ╚════██║██╔══╝  ██╔══██║██╔══██╗██║     ██╔══██║██╔══╝  ██╔══██╗
                           ███████║███████╗██║  ██║██║  ██║╚██████╗██║  ██║███████╗██║  ██║
                           ╚══════╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                   
                                                                                   ''')


    def main(dossier, pseudo):
        resultat = []
    
        
        for dossier_actuel, sous_dossiers, fichiers in os.walk(dossier):
            for nom_fichier in fichiers:
                chemin_fichier = os.path.join(dossier_actuel, nom_fichier)
    
                with open(chemin_fichier, 'r', encoding='ISO-8859-1') as fichier:
                    lignes = fichier.readlines()
                    for index, ligne in enumerate(lignes):
                        if pseudo in ligne:
                            resultat.append((chemin_fichier, index+1, ligne.strip()))
                            
        return resultat
    
    
    pseudo_cherche = input(f'  {pystyle.Colors.white}Recherche : {pystyle.Colors.red}')
    dossier_DB = "DB PAYPAL"
    resultat_recherche = main(dossier_DB, pseudo_cherche)
    
    
    if resultat_recherche:
        for chemin, numero_ligne, contenu_ligne in resultat_recherche:
            print(f"Le pseudo a été trouvé dans le fichier : {chemin}")
            print(f"Ligne {numero_ligne}: {contenu_ligne}")
            print("\n--------\n")
    else:
        print("Le pseudo n'a pas été trouvé dans les fichiers du dossier.")
        input(f"{Colors.red}Entrer {Colors.white}pour {Colors.red}quitter{Colors.pink}")
    clear()
    print(f'''{Colors.blue}
                          
                                              GMS {Colors.white}X {Colors.orange}TR4X
        

        {m}[{w}1{Fore.RESET}{m}]{Fore.RESET} Searcher DB FM               {m}[{w }8{Fore.RESET}{m}]{Fore.RESET}  Searcher DB PLAY
        {m}[{w}2{Fore.RESET}{m}]{Fore.RESET} Searcher DB MAIL             {m}[{w }9{Fore.RESET}{m}]{Fore.RESET}  Searcher DB EPIC
        {m}[{w}3{Fore.RESET}{m}]{Fore.RESET} Searcher DB MASTERCARD       {m}[{w}10{Fore.RESET}{m}]{Fore.RESET} Searcher DB BDV
        {m}[{w}4{Fore.RESET}{m}]{Fore.RESET} Searcher DB PAYPAL           {m}[{w}11{Fore.RESET}{m}]{Fore.RESET} Searcher DB DISCORD         
        {m}[{w}5{Fore.RESET}{m}]{Fore.RESET} Searcher DB ROBLOX           {m}[{w}12{Fore.RESET}{m}]{Fore.RESET} Searcher DB MINECRAFT
        {m}[{w}6{Fore.RESET}{m}]{Fore.RESET} Searcher DB SNAPCHAT         {m}[{w}13{Fore.RESET}{m}]{Fore.RESET} IP Lookup
        {m}[{w}7{Fore.RESET}{m}]{Fore.RESET} Searcher DB VALORANT        {b}|{Fore.RESET}{m}[{w}14{Fore.RESET}{m}]{Fore.RESET}{lr} EXIT{Fore.RESET}
      
''')
 if option == "5":
    clear()
    clear()
    print(f'''

                           {pystyle.Colors.white}███████╗███████╗ █████╗ ██████╗  ██████╗██╗  ██╗███████╗██████╗ 
                           ██╔════╝██╔════╝██╔══██╗██╔══██╗██╔════╝██║  ██║██╔════╝██╔══██╗
                           ███████╗█████╗  ███████║██████╔╝██║     ███████║█████╗  ██████╔╝
                           ╚════██║██╔══╝  ██╔══██║██╔══██╗██║     ██╔══██║██╔══╝  ██╔══██╗
                           ███████║███████╗██║  ██║██║  ██║╚██████╗██║  ██║███████╗██║  ██║
                           ╚══════╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                   
                                                                                   ''')


    def main(dossier, pseudo):
        resultat = []
    
        
        for dossier_actuel, sous_dossiers, fichiers in os.walk(dossier):
            for nom_fichier in fichiers:
                chemin_fichier = os.path.join(dossier_actuel, nom_fichier)
    
                with open(chemin_fichier, 'r', encoding='ISO-8859-1') as fichier:
                    lignes = fichier.readlines()
                    for index, ligne in enumerate(lignes):
                        if pseudo in ligne:
                            resultat.append((chemin_fichier, index+1, ligne.strip()))
                            
        return resultat
    
    
    pseudo_cherche = input(f'  {pystyle.Colors.white}Recherche : {pystyle.Colors.red}')
    dossier_DB = "DB ROBLOX"
    resultat_recherche = main(dossier_DB, pseudo_cherche)
    
    
    if resultat_recherche:
        for chemin, numero_ligne, contenu_ligne in resultat_recherche:
            print(f"Le pseudo a été trouvé dans le fichier : {chemin}")
            print(f"Ligne {numero_ligne}: {contenu_ligne}")
            print("\n--------\n")
    else:
        print("Le pseudo n'a pas été trouvé dans les fichiers du dossier.")
        input(f"{Colors.red}Entrer {Colors.white}pour {Colors.red}quitter{Colors.pink}")
    clear()
    print(f'''{Colors.blue}
                          
                                              GMS {Colors.white}X {Colors.orange}TR4X
        

        {m}[{w}1{Fore.RESET}{m}]{Fore.RESET} Searcher DB FM               {m}[{w }8{Fore.RESET}{m}]{Fore.RESET}  Searcher DB PLAY
        {m}[{w}2{Fore.RESET}{m}]{Fore.RESET} Searcher DB MAIL             {m}[{w }9{Fore.RESET}{m}]{Fore.RESET}  Searcher DB EPIC
        {m}[{w}3{Fore.RESET}{m}]{Fore.RESET} Searcher DB MASTERCARD       {m}[{w}10{Fore.RESET}{m}]{Fore.RESET} Searcher DB BDV
        {m}[{w}4{Fore.RESET}{m}]{Fore.RESET} Searcher DB PAYPAL           {m}[{w}11{Fore.RESET}{m}]{Fore.RESET} Searcher DB DISCORD         
        {m}[{w}5{Fore.RESET}{m}]{Fore.RESET} Searcher DB ROBLOX           {m}[{w}12{Fore.RESET}{m}]{Fore.RESET} Searcher DB MINECRAFT
        {m}[{w}6{Fore.RESET}{m}]{Fore.RESET} Searcher DB SNAPCHAT         {m}[{w}13{Fore.RESET}{m}]{Fore.RESET} IP Lookup
        {m}[{w}7{Fore.RESET}{m}]{Fore.RESET} Searcher DB VALORANT        {b}|{Fore.RESET}{m}[{w}14{Fore.RESET}{m}]{Fore.RESET}{lr} EXIT{Fore.RESET}
      
''')
 if option == "6":
    clear()
    clear()
    print(f'''

                           {pystyle.Colors.white}███████╗███████╗ █████╗ ██████╗  ██████╗██╗  ██╗███████╗██████╗ 
                           ██╔════╝██╔════╝██╔══██╗██╔══██╗██╔════╝██║  ██║██╔════╝██╔══██╗
                           ███████╗█████╗  ███████║██████╔╝██║     ███████║█████╗  ██████╔╝
                           ╚════██║██╔══╝  ██╔══██║██╔══██╗██║     ██╔══██║██╔══╝  ██╔══██╗
                           ███████║███████╗██║  ██║██║  ██║╚██████╗██║  ██║███████╗██║  ██║
                           ╚══════╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                   
                                                                                   ''')


    def main(dossier, pseudo):
        resultat = []
    
        
        for dossier_actuel, sous_dossiers, fichiers in os.walk(dossier):
            for nom_fichier in fichiers:
                chemin_fichier = os.path.join(dossier_actuel, nom_fichier)
    
                with open(chemin_fichier, 'r', encoding='ISO-8859-1') as fichier:
                    lignes = fichier.readlines()
                    for index, ligne in enumerate(lignes):
                        if pseudo in ligne:
                            resultat.append((chemin_fichier, index+1, ligne.strip()))
                            
        return resultat
    
    
    pseudo_cherche = input(f'  {pystyle.Colors.white}Recherche : {pystyle.Colors.red}')
    dossier_DB = "DB SNAPCHAT"
    resultat_recherche = main(dossier_DB, pseudo_cherche)
    
    
    if resultat_recherche:
        for chemin, numero_ligne, contenu_ligne in resultat_recherche:
            print(f"Le pseudo a été trouvé dans le fichier : {chemin}")
            print(f"Ligne {numero_ligne}: {contenu_ligne}")
            print("\n--------\n")
    else:
        print("Le pseudo n'a pas été trouvé dans les fichiers du dossier.")
        iinput(f"{Colors.red}Press {Colors.blue}ENTER {Colors.red}to exit!{Colors.pink}")
    clear()
    print(f'''{Colors.blue}
                          
                                              GMS {Colors.white}X {Colors.orange}TR4X
        

        {m}[{w}1{Fore.RESET}{m}]{Fore.RESET} Searcher DB FM               {m}[{w }8{Fore.RESET}{m}]{Fore.RESET}  Searcher DB PLAY
        {m}[{w}2{Fore.RESET}{m}]{Fore.RESET} Searcher DB MAIL             {m}[{w }9{Fore.RESET}{m}]{Fore.RESET}  Searcher DB EPIC
        {m}[{w}3{Fore.RESET}{m}]{Fore.RESET} Searcher DB MASTERCARD       {m}[{w}10{Fore.RESET}{m}]{Fore.RESET} Searcher DB BDV
        {m}[{w}4{Fore.RESET}{m}]{Fore.RESET} Searcher DB PAYPAL           {m}[{w}11{Fore.RESET}{m}]{Fore.RESET} Searcher DB DISCORD         
        {m}[{w}5{Fore.RESET}{m}]{Fore.RESET} Searcher DB ROBLOX           {m}[{w}12{Fore.RESET}{m}]{Fore.RESET} Searcher DB MINECRAFT
        {m}[{w}6{Fore.RESET}{m}]{Fore.RESET} Searcher DB SNAPCHAT         {m}[{w}13{Fore.RESET}{m}]{Fore.RESET} IP Lookup
        {m}[{w}7{Fore.RESET}{m}]{Fore.RESET} Searcher DB VALORANT        {b}|{Fore.RESET}{m}[{w}14{Fore.RESET}{m}]{Fore.RESET}{lr} EXIT{Fore.RESET}
      
''')
 if option == "7":
    clear()
    clear()
    print(f'''

                           {pystyle.Colors.white}███████╗███████╗ █████╗ ██████╗  ██████╗██╗  ██╗███████╗██████╗ 
                           ██╔════╝██╔════╝██╔══██╗██╔══██╗██╔════╝██║  ██║██╔════╝██╔══██╗
                           ███████╗█████╗  ███████║██████╔╝██║     ███████║█████╗  ██████╔╝
                           ╚════██║██╔══╝  ██╔══██║██╔══██╗██║     ██╔══██║██╔══╝  ██╔══██╗
                           ███████║███████╗██║  ██║██║  ██║╚██████╗██║  ██║███████╗██║  ██║
                           ╚══════╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                   
                                                                                   ''')


    def main(dossier, pseudo):
        resultat = []
    
        
        for dossier_actuel, sous_dossiers, fichiers in os.walk(dossier):
            for nom_fichier in fichiers:
                chemin_fichier = os.path.join(dossier_actuel, nom_fichier)
    
                with open(chemin_fichier, 'r', encoding='ISO-8859-1') as fichier:
                    lignes = fichier.readlines()
                    for index, ligne in enumerate(lignes):
                        if pseudo in ligne:
                            resultat.append((chemin_fichier, index+1, ligne.strip()))
                            
        return resultat
    
    
    pseudo_cherche = input(f'  {pystyle.Colors.white}Recherche : {pystyle.Colors.red}')
    dossier_DB = "DB VALO"
    resultat_recherche = main(dossier_DB, pseudo_cherche)
    
    
    if resultat_recherche:
        for chemin, numero_ligne, contenu_ligne in resultat_recherche:
            print(f"Le pseudo a été trouvé dans le fichier : {chemin}")
            print(f"Ligne {numero_ligne}: {contenu_ligne}")
            print("\n--------\n")
    else:
        print("Le pseudo n'a pas été trouvé dans les fichiers du dossier.")
        input(f"{Colors.red}Entrer {Colors.white}pour {Colors.red}quitter{Colors.pink}")
    clear()
    print(f'''{Colors.blue}
                          
                                              GMS {Colors.white}X {Colors.orange}TR4X
        

        {m}[{w}1{Fore.RESET}{m}]{Fore.RESET} Searcher DB FM               {m}[{w }8{Fore.RESET}{m}]{Fore.RESET}  Searcher DB PLAY
        {m}[{w}2{Fore.RESET}{m}]{Fore.RESET} Searcher DB MAIL             {m}[{w }9{Fore.RESET}{m}]{Fore.RESET}  Searcher DB EPIC
        {m}[{w}3{Fore.RESET}{m}]{Fore.RESET} Searcher DB MASTERCARD       {m}[{w}10{Fore.RESET}{m}]{Fore.RESET} Searcher DB BDV
        {m}[{w}4{Fore.RESET}{m}]{Fore.RESET} Searcher DB PAYPAL           {m}[{w}11{Fore.RESET}{m}]{Fore.RESET} Searcher DB DISCORD         
        {m}[{w}5{Fore.RESET}{m}]{Fore.RESET} Searcher DB ROBLOX           {m}[{w}12{Fore.RESET}{m}]{Fore.RESET} Searcher DB MINECRAFT
        {m}[{w}6{Fore.RESET}{m}]{Fore.RESET} Searcher DB SNAPCHAT         {m}[{w}13{Fore.RESET}{m}]{Fore.RESET} IP Lookup
        {m}[{w}7{Fore.RESET}{m}]{Fore.RESET} Searcher DB VALORANT        {b}|{Fore.RESET}{m}[{w}14{Fore.RESET}{m}]{Fore.RESET}{lr} EXIT{Fore.RESET}
      
''')
 if option == "8":
    clear()
    clear()
    print(f'''

                           {pystyle.Colors.white}███████╗███████╗ █████╗ ██████╗  ██████╗██╗  ██╗███████╗██████╗ 
                           ██╔════╝██╔════╝██╔══██╗██╔══██╗██╔════╝██║  ██║██╔════╝██╔══██╗
                           ███████╗█████╗  ███████║██████╔╝██║     ███████║█████╗  ██████╔╝
                           ╚════██║██╔══╝  ██╔══██║██╔══██╗██║     ██╔══██║██╔══╝  ██╔══██╗
                           ███████║███████╗██║  ██║██║  ██║╚██████╗██║  ██║███████╗██║  ██║
                           ╚══════╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                   
                                                                                   ''')


    def main(dossier, pseudo):
        resultat = []
    
        
        for dossier_actuel, sous_dossiers, fichiers in os.walk(dossier):
            for nom_fichier in fichiers:
                chemin_fichier = os.path.join(dossier_actuel, nom_fichier)
    
                with open(chemin_fichier, 'r', encoding='ISO-8859-1') as fichier:
                    lignes = fichier.readlines()
                    for index, ligne in enumerate(lignes):
                        if pseudo in ligne:
                            resultat.append((chemin_fichier, index+1, ligne.strip()))
                            
        return resultat
    
    
    pseudo_cherche = input(f'  {pystyle.Colors.white}Recherche : {pystyle.Colors.red}')
    dossier_DB = "DB PLAY"
    resultat_recherche = main(dossier_DB, pseudo_cherche)
    
    
    if resultat_recherche:
        for chemin, numero_ligne, contenu_ligne in resultat_recherche:
            print(f"Le pseudo a été trouvé dans le fichier : {chemin}")
            print(f"Ligne {numero_ligne}: {contenu_ligne}")
            print("\n--------\n")
    else:
        print("Le pseudo n'a pas été trouvé dans les fichiers du dossier.")
        input(f"{Colors.red}Entrer {Colors.white}pour {Colors.red}quitter{Colors.pink}")
    clear()
    print(f'''{Colors.blue}
                          
                                              GMS {Colors.white}X {Colors.orange}TR4X
        

        {m}[{w}1{Fore.RESET}{m}]{Fore.RESET} Searcher DB FM               {m}[{w }8{Fore.RESET}{m}]{Fore.RESET}  Searcher DB PLAY
        {m}[{w}2{Fore.RESET}{m}]{Fore.RESET} Searcher DB MAIL             {m}[{w }9{Fore.RESET}{m}]{Fore.RESET}  Searcher DB EPIC
        {m}[{w}3{Fore.RESET}{m}]{Fore.RESET} Searcher DB MASTERCARD       {m}[{w}10{Fore.RESET}{m}]{Fore.RESET} Searcher DB BDV
        {m}[{w}4{Fore.RESET}{m}]{Fore.RESET} Searcher DB PAYPAL           {m}[{w}11{Fore.RESET}{m}]{Fore.RESET} Searcher DB DISCORD         
        {m}[{w}5{Fore.RESET}{m}]{Fore.RESET} Searcher DB ROBLOX           {m}[{w}12{Fore.RESET}{m}]{Fore.RESET} Searcher DB MINECRAFT
        {m}[{w}6{Fore.RESET}{m}]{Fore.RESET} Searcher DB SNAPCHAT         {m}[{w}13{Fore.RESET}{m}]{Fore.RESET} IP Lookup
        {m}[{w}7{Fore.RESET}{m}]{Fore.RESET} Searcher DB VALORANT        {b}|{Fore.RESET}{m}[{w}14{Fore.RESET}{m}]{Fore.RESET}{lr} EXIT{Fore.RESET}
      
''')
 if option == "9":
    clear()
    clear()
    print(f'''

                           {pystyle.Colors.white}███████╗███████╗ █████╗ ██████╗  ██████╗██╗  ██╗███████╗██████╗ 
                           ██╔════╝██╔════╝██╔══██╗██╔══██╗██╔════╝██║  ██║██╔════╝██╔══██╗
                           ███████╗█████╗  ███████║██████╔╝██║     ███████║█████╗  ██████╔╝
                           ╚════██║██╔══╝  ██╔══██║██╔══██╗██║     ██╔══██║██╔══╝  ██╔══██╗
                           ███████║███████╗██║  ██║██║  ██║╚██████╗██║  ██║███████╗██║  ██║
                           ╚══════╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                   
                                                                                   ''')


    def main(dossier, pseudo):
        resultat = []
    
        
        for dossier_actuel, sous_dossiers, fichiers in os.walk(dossier):
            for nom_fichier in fichiers:
                chemin_fichier = os.path.join(dossier_actuel, nom_fichier)
    
                with open(chemin_fichier, 'r', encoding='ISO-8859-1') as fichier:
                    lignes = fichier.readlines()
                    for index, ligne in enumerate(lignes):
                        if pseudo in ligne:
                            resultat.append((chemin_fichier, index+1, ligne.strip()))
                            
        return resultat
    
    
    pseudo_cherche = input(f'  {pystyle.Colors.white}Recherche : {pystyle.Colors.red}')
    dossier_DB = "DB EPIC"
    resultat_recherche = main(dossier_DB, pseudo_cherche)
    
    
    if resultat_recherche:
        for chemin, numero_ligne, contenu_ligne in resultat_recherche:
            print(f"Le pseudo a été trouvé dans le fichier : {chemin}")
            print(f"Ligne {numero_ligne}: {contenu_ligne}")
            print("\n--------\n")
    else:
        print("Le pseudo n'a pas été trouvé dans les fichiers du dossier.")
        input(f"{Colors.red}Entrer {Colors.white}pour {Colors.red}quitter{Colors.pink}")
    clear()
    print(f'''{Colors.blue}
                          
                                              GMS {Colors.white}X {Colors.orange}TR4X
        

        {m}[{w}1{Fore.RESET}{m}]{Fore.RESET} Searcher DB FM               {m}[{w }8{Fore.RESET}{m}]{Fore.RESET}  Searcher DB PLAY
        {m}[{w}2{Fore.RESET}{m}]{Fore.RESET} Searcher DB MAIL             {m}[{w }9{Fore.RESET}{m}]{Fore.RESET}  Searcher DB EPIC
        {m}[{w}3{Fore.RESET}{m}]{Fore.RESET} Searcher DB MASTERCARD       {m}[{w}10{Fore.RESET}{m}]{Fore.RESET} Searcher DB BDV
        {m}[{w}4{Fore.RESET}{m}]{Fore.RESET} Searcher DB PAYPAL           {m}[{w}11{Fore.RESET}{m}]{Fore.RESET} Searcher DB DISCORD         
        {m}[{w}5{Fore.RESET}{m}]{Fore.RESET} Searcher DB ROBLOX           {m}[{w}12{Fore.RESET}{m}]{Fore.RESET} Searcher DB MINECRAFT
        {m}[{w}6{Fore.RESET}{m}]{Fore.RESET} Searcher DB SNAPCHAT         {m}[{w}13{Fore.RESET}{m}]{Fore.RESET} IP Lookup
        {m}[{w}7{Fore.RESET}{m}]{Fore.RESET} Searcher DB VALORANT        {b}|{Fore.RESET}{m}[{w}14{Fore.RESET}{m}]{Fore.RESET}{lr} EXIT{Fore.RESET}
      
''')
 if option == "10":
    clear()
    clear()
    print(f'''

                           {pystyle.Colors.white}███████╗███████╗ █████╗ ██████╗  ██████╗██╗  ██╗███████╗██████╗ 
                           ██╔════╝██╔════╝██╔══██╗██╔══██╗██╔════╝██║  ██║██╔════╝██╔══██╗
                           ███████╗█████╗  ███████║██████╔╝██║     ███████║█████╗  ██████╔╝
                           ╚════██║██╔══╝  ██╔══██║██╔══██╗██║     ██╔══██║██╔══╝  ██╔══██╗
                           ███████║███████╗██║  ██║██║  ██║╚██████╗██║  ██║███████╗██║  ██║
                           ╚══════╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                   
                                                                                   ''')


    def main(dossier, pseudo):
        resultat = []
    
        
        for dossier_actuel, sous_dossiers, fichiers in os.walk(dossier):
            for nom_fichier in fichiers:
                chemin_fichier = os.path.join(dossier_actuel, nom_fichier)
    
                with open(chemin_fichier, 'r', encoding='ISO-8859-1') as fichier:
                    lignes = fichier.readlines()
                    for index, ligne in enumerate(lignes):
                        if pseudo in ligne:
                            resultat.append((chemin_fichier, index+1, ligne.strip()))
                            
        return resultat
    
    
    pseudo_cherche = input(f'  {pystyle.Colors.white}Recherche : {pystyle.Colors.red}')
    dossier_DB = "DB BDV"
    resultat_recherche = main(dossier_DB, pseudo_cherche)
    
    
    if resultat_recherche:
        for chemin, numero_ligne, contenu_ligne in resultat_recherche:
            print(f"Le pseudo a été trouvé dans le fichier : {chemin}")
            print(f"Ligne {numero_ligne}: {contenu_ligne}")
            print("\n--------\n")
    else:
        print("Le pseudo n'a pas été trouvé dans les fichiers du dossier.")
        input(f"{Colors.red}Entrer {Colors.white}pour {Colors.red}quitter{Colors.pink}")
    clear()
    print(f'''{Colors.blue}
                          
                                              GMS {Colors.white}X {Colors.orange}TR4X
        

        {m}[{w}1{Fore.RESET}{m}]{Fore.RESET} Searcher DB FM               {m}[{w }8{Fore.RESET}{m}]{Fore.RESET}  Searcher DB PLAY
        {m}[{w}2{Fore.RESET}{m}]{Fore.RESET} Searcher DB MAIL             {m}[{w }9{Fore.RESET}{m}]{Fore.RESET}  Searcher DB EPIC
        {m}[{w}3{Fore.RESET}{m}]{Fore.RESET} Searcher DB MASTERCARD       {m}[{w}10{Fore.RESET}{m}]{Fore.RESET} Searcher DB BDV
        {m}[{w}4{Fore.RESET}{m}]{Fore.RESET} Searcher DB PAYPAL           {m}[{w}11{Fore.RESET}{m}]{Fore.RESET} Searcher DB DISCORD         
        {m}[{w}5{Fore.RESET}{m}]{Fore.RESET} Searcher DB ROBLOX           {m}[{w}12{Fore.RESET}{m}]{Fore.RESET} Searcher DB MINECRAFT
        {m}[{w}6{Fore.RESET}{m}]{Fore.RESET} Searcher DB SNAPCHAT         {m}[{w}13{Fore.RESET}{m}]{Fore.RESET} IP Lookup
        {m}[{w}7{Fore.RESET}{m}]{Fore.RESET} Searcher DB VALORANT        {b}|{Fore.RESET}{m}[{w}14{Fore.RESET}{m}]{Fore.RESET}{lr} EXIT{Fore.RESET}
      
''')
 if option == "11":
    clear()
    clear()
    print(f'''

                           {pystyle.Colors.white}███████╗███████╗ █████╗ ██████╗  ██████╗██╗  ██╗███████╗██████╗ 
                           ██╔════╝██╔════╝██╔══██╗██╔══██╗██╔════╝██║  ██║██╔════╝██╔══██╗
                           ███████╗█████╗  ███████║██████╔╝██║     ███████║█████╗  ██████╔╝
                           ╚════██║██╔══╝  ██╔══██║██╔══██╗██║     ██╔══██║██╔══╝  ██╔══██╗
                           ███████║███████╗██║  ██║██║  ██║╚██████╗██║  ██║███████╗██║  ██║
                           ╚══════╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                   
                                                                                   ''')


    def main(dossier, pseudo):
        resultat = []
    
        
        for dossier_actuel, sous_dossiers, fichiers in os.walk(dossier):
            for nom_fichier in fichiers:
                chemin_fichier = os.path.join(dossier_actuel, nom_fichier)
    
                with open(chemin_fichier, 'r', encoding='ISO-8859-1') as fichier:
                    lignes = fichier.readlines()
                    for index, ligne in enumerate(lignes):
                        if pseudo in ligne:
                            resultat.append((chemin_fichier, index+1, ligne.strip()))
                            
        return resultat
    
    
    pseudo_cherche = input(f'  {pystyle.Colors.white}Recherche : {pystyle.Colors.red}')
    dossier_DB = "DB DISCORD"
    resultat_recherche = main(dossier_DB, pseudo_cherche)
    
    
    if resultat_recherche:
        for chemin, numero_ligne, contenu_ligne in resultat_recherche:
            print(f"Le pseudo a été trouvé dans le fichier : {chemin}")
            print(f"Ligne {numero_ligne}: {contenu_ligne}")
            print("\n--------\n")
    else:
        print("Le pseudo n'a pas été trouvé dans les fichiers du dossier.")
        input(f"{Colors.red}Entrer {Colors.white}pour {Colors.red}quitter{Colors.pink}")
    clear()
    print(f'''{Colors.blue}
                          
                                              GMS {Colors.white}X {Colors.orange}TR4X
        

        {m}[{w}1{Fore.RESET}{m}]{Fore.RESET} Searcher DB FM               {m}[{w }8{Fore.RESET}{m}]{Fore.RESET}  Searcher DB PLAY
        {m}[{w}2{Fore.RESET}{m}]{Fore.RESET} Searcher DB MAIL             {m}[{w }9{Fore.RESET}{m}]{Fore.RESET}  Searcher DB EPIC
        {m}[{w}3{Fore.RESET}{m}]{Fore.RESET} Searcher DB MASTERCARD       {m}[{w}10{Fore.RESET}{m}]{Fore.RESET} Searcher DB BDV
        {m}[{w}4{Fore.RESET}{m}]{Fore.RESET} Searcher DB PAYPAL           {m}[{w}11{Fore.RESET}{m}]{Fore.RESET} Searcher DB DISCORD         
        {m}[{w}5{Fore.RESET}{m}]{Fore.RESET} Searcher DB ROBLOX           {m}[{w}12{Fore.RESET}{m}]{Fore.RESET} Searcher DB MINECRAFT
        {m}[{w}6{Fore.RESET}{m}]{Fore.RESET} Searcher DB SNAPCHAT         {m}[{w}13{Fore.RESET}{m}]{Fore.RESET} IP Lookup
        {m}[{w}7{Fore.RESET}{m}]{Fore.RESET} Searcher DB VALORANT        {b}|{Fore.RESET}{m}[{w}14{Fore.RESET}{m}]{Fore.RESET}{lr} EXIT{Fore.RESET}
      
''')
 if option == "12":
    clear()
    clear()
    print(f'''

                           {pystyle.Colors.white}███████╗███████╗ █████╗ ██████╗  ██████╗██╗  ██╗███████╗██████╗ 
                           ██╔════╝██╔════╝██╔══██╗██╔══██╗██╔════╝██║  ██║██╔════╝██╔══██╗
                           ███████╗█████╗  ███████║██████╔╝██║     ███████║█████╗  ██████╔╝
                           ╚════██║██╔══╝  ██╔══██║██╔══██╗██║     ██╔══██║██╔══╝  ██╔══██╗
                           ███████║███████╗██║  ██║██║  ██║╚██████╗██║  ██║███████╗██║  ██║
                           ╚══════╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                   
                                                                                   ''')


    def main(dossier, pseudo):
        resultat = []
    
        
        for dossier_actuel, sous_dossiers, fichiers in os.walk(dossier):
            for nom_fichier in fichiers:
                chemin_fichier = os.path.join(dossier_actuel, nom_fichier)
    
                with open(chemin_fichier, 'r', encoding='ISO-8859-1') as fichier:
                    lignes = fichier.readlines()
                    for index, ligne in enumerate(lignes):
                        if pseudo in ligne:
                            resultat.append((chemin_fichier, index+1, ligne.strip()))
                            
        return resultat
    
    
    pseudo_cherche = input(f'  {pystyle.Colors.white}Recherche : {pystyle.Colors.red}')
    dossier_DB = "DB MINECRAFT"
    resultat_recherche = main(dossier_DB, pseudo_cherche)
    
    
    if resultat_recherche:
        for chemin, numero_ligne, contenu_ligne in resultat_recherche:
            print(f"Le pseudo a été trouvé dans le fichier : {chemin}")
            print(f"Ligne {numero_ligne}: {contenu_ligne}")
            print("\n--------\n")
    else:
        print("Le pseudo n'a pas été trouvé dans les fichiers du dossier.")
        input(f"{Colors.red}Entrer {Colors.white}pour {Colors.red}quitter{Colors.pink}")
    clear()
    print(f'''{Colors.blue}
                          
                                              GMS {Colors.white}X {Colors.orange}TR4X
        

        {m}[{w}1{Fore.RESET}{m}]{Fore.RESET} Searcher DB FM               {m}[{w }8{Fore.RESET}{m}]{Fore.RESET}  Searcher DB PLAY
        {m}[{w}2{Fore.RESET}{m}]{Fore.RESET} Searcher DB MAIL             {m}[{w }9{Fore.RESET}{m}]{Fore.RESET}  Searcher DB EPIC
        {m}[{w}3{Fore.RESET}{m}]{Fore.RESET} Searcher DB MASTERCARD       {m}[{w}10{Fore.RESET}{m}]{Fore.RESET} Searcher DB BDV
        {m}[{w}4{Fore.RESET}{m}]{Fore.RESET} Searcher DB PAYPAL           {m}[{w}11{Fore.RESET}{m}]{Fore.RESET} Searcher DB DISCORD         
        {m}[{w}5{Fore.RESET}{m}]{Fore.RESET} Searcher DB ROBLOX           {m}[{w}12{Fore.RESET}{m}]{Fore.RESET} Searcher DB MINECRAFT
        {m}[{w}6{Fore.RESET}{m}]{Fore.RESET} Searcher DB SNAPCHAT         {m}[{w}13{Fore.RESET}{m}]{Fore.RESET} IP Lookup
        {m}[{w}7{Fore.RESET}{m}]{Fore.RESET} Searcher DB VALORANT        {b}|{Fore.RESET}{m}[{w}14{Fore.RESET}{m}]{Fore.RESET}{lr} EXIT{Fore.RESET}
      
 ''')
 
 if option == "13":
  clear()
 clear()
 print(f'''

                           {pystyle.Colors.white}███████╗███████╗ █████╗ ██████╗  ██████╗██╗  ██╗███████╗██████╗ 
                           ██╔════╝██╔════╝██╔══██╗██╔══██╗██╔════╝██║  ██║██╔════╝██╔══██╗
                           ███████╗█████╗  ███████║██████╔╝██║     ███████║█████╗  ██████╔╝
                           ╚════██║██╔══╝  ██╔══██║██╔══██╗██║     ██╔══██║██╔══╝  ██╔══██╗
                           ███████║███████╗██║  ██║██║  ██║╚██████╗██║  ██║███████╗██║  ██║
                           ╚══════╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝

 {pystyle.Colors.white}                                                                                  ''')

 file_path = r'C:\Users\Ylhan\Desktop\tr4x\teste\main.py'

    # Open the file using the default program
 if os.name == 'nt':
        os.startfile(file_path)
else:
        subprocess.call(('xdg-open', file_path))


