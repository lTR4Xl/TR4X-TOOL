import threading
import pystyle
import time

LocheMan = ['...', 'A...' ,'Aw...' ,'Awa...' ,'Awai...' ,'Await...','Await' ,'Await...' ,'Await' ,'Await...' ,'Await' ,'Await...' ,'Await' \
            ,'Awai' ,'Awa' ,'Aw' ,'A']

def locheman():
    global stop
    stop = False

    global isImported
    isImported = False
    while not stop:
        number = 0
        for title in LocheMan:
            if not stop:
                number += 1
                if title == 'Await' or title == 'Await...':
                    pystyle.System.Title(f'TR4X  -  By {title}')
                    time.sleep(0.5)
                else:
                    pystyle.System.Title(f'TR4X  -  By {title}')
                    time.sleep(0.1)
            else:
                pass

def start():
    title = threading.Thread(target=locheman)
    title.start()

def stop():
    stop = True
    pystyle.System.Title(f'TR4X  -  By Await')