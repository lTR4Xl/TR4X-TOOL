from pystyle import *
import time
import threading

Await_WaterMark = [f'''                     ██████  ▄▄▄     ▓██   ██▓ █    ██  ██▀███   ██▓   ▄▄▄█████▓ ▒█████   ▒█████   ██▓    
                   ▒██    ▒ ▒████▄    ▒██  ██▒ ██  ▓██▒▓██ ▒ ██▒▓██▒   ▓  ██▒ ▓▒▒██▒  ██▒▒██▒  ██▒▓██▒    
                   ░ ▓██▄   ▒██  ▀█▄   ▒██ ██░▓██  ▒██░▓██ ░▄█ ▒▒██▒   ▒ ▓██░ ▒░▒██░  ██▒▒██░  ██▒▒██░    
                     ▒   ██▒░██▄▄▄▄██  ░ ▐██▓░▓▓█  ░██░▒██▀▀█▄  ░██░   ░ ▓██▓ ░ ▒██   ██░▒██   ██░▒██░    
                   ▒██████▒▒ ▓█   ▓██▒ ░ ██▒▓░▒▒█████▓ ░██▓ ▒██▒░██░     ▒██▒ ░ ░ ████▓▒░░ ████▓▒░░██████▒
                   ▒ ▒▓▒ ▒ ░ ▒▒   ▓▒█░  ██▒▒▒ ░▒▓▒ ▒ ▒ ░ ▒▓ ░▒▓░░▓       ▒ ░░   ░ ▒░▒░▒░ ░ ▒░▒░▒░ ░ ▒░▓  ░
                   ░ ░▒  ░ ░  ▒   ▒▒ ░▓██ ░▒░ ░░▒░ ░ ░   ░▒ ░ ▒░ ▒ ░       ░      ░ ▒ ▒░   ░ ▒ ▒░ ░ ░ ▒  ░
                   ░  ░  ░    ░   ▒   ▒ ▒ ░░   ░░░ ░ ░   ░░   ░  ▒ ░     ░      ░ ░ ░ ▒  ░ ░ ░ ▒    ░ ░   
                      ░        ░  ░░ ░        ░        ░      ░                  ░ ░      ░ ░      ░  ░
                                   ░ ░                                                                 
                                                   
                                       ╔══════════════╦══════════════╦══════════════╗
                                       ║     [1]      ║     [2]      ║      [3]     ║
                                       ║Server Lookup ║  IP Lookup   ║    Grabber   ║
                                       ║              ║              ║    Builder   ║
                              ╔════════╩═════╦════════╩═══════╦══════╩════════╦═════╩════════╗    
                              ║     [4]      ║      [5]       ║      [6]      ║      [7]     ║
                              ║  Token Info  ║    NitroGen    ║    MassDM     ║Account Nuker ║
                              ║              ║                ║               ║              ║
                              ╚══════════════╩════════════════╩═══════════════╩══════════════╝                   
''']

for part in Await_WaterMark:
    print(Colorate.Horizontal(Colors.blue_to_red, part, 1))
    time.sleep(0.05)

def start():
    Await_WaterMark = threading.Thread(target=Await_WaterMark)
    Await_WaterMark.start()

    
print('') # sauter des lignes vite fait pour le style (lol)
print('')
print('')
print('')